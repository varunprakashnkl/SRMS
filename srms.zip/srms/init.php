<?php
	$servername = "localhost";
	$username = "unistamv";
	$password = "Varunnkl01@";
	$conn = mysqli_connect($servername, $username, $password);
	$db = mysqli_select_db($conn,'unistam');


?>